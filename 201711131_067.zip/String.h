//
// Created by Hoseop Shin on 2023-01-11.
//

#include <stddef.h>
class String {
public:
    String();
    String(const char* str);
    String(const String& str);
    String& operator=(const String& str);
    ~String();
    const char* data() const;
    char& at(size_t);
    size_t size() const;
    void print(const char* str="") const;
private:
    int len;
    char* s;
};
