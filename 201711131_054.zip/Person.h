//
// Created by Hoseop Shin on 2023-01-10.
//

#include <string>

class Person {
public:
    Person(std::string name, std::string number);
    void modifyNumber(std::string number);
    void print() const;

private:
    std::string name;
    std::string number;
};