//
// Created by Hoseop Shin on 12/01/2023.
//

#include <string>
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>

class Person {
public:
    Person(std::string name, size_t age) : name{name}, age{age} {
        static long long id = 1;
        ID = id;
        id++;
    }

    friend std::ostream& operator << (std::ostream& out, const Person& p) {
        out << p.ID << " " << p.name << " " << p.age;
        return out;
    }

    bool operator < (const Person& rhs) const {
        return ID < rhs.ID;
    }

    class ComparatorByAge {
    public:
        bool operator()(const Person& lhs, const Person& rhs) const{
            return lhs.age < rhs.age;
        }
    };

    class ComparatorByName {
    public:
        bool operator()(const Person& lhs, const Person& rhs) const{
            return lhs.name < rhs.name;
        }
    };

private:
    long long ID;
    std::string name;
    size_t age;
};
