//
// Created by Hoseop Shin on 2023-01-11.
//

#include <stddef.h>

class Array {
public:
    Array(std::initializer_list<int> d, size_t size);
    Array(const Array& arr);
    Array& operator=(const Array& arr);
    ~Array();
    int& at(size_t size);
    std::string print() const;
private:
    int* data = nullptr;
    size_t _size = 0;
};
