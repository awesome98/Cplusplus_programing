
class Cents {
    long cent=0;
public:
    Cents(long c) : cent(c) {}
    Cents& operator=(const Cents& c) {
        cent = c.cent;
        return *this;
    }
    friend class Dollars;
    explicit operator int() const {
        return (int)cent;
    }
};
class Dollars {
    long dollar=0;
public:
    Dollars(long d) : dollar(d) {}
    explicit operator Cents() const {
        return Cents(dollar*100);
    }
};
