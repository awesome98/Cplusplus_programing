//
// Created by Hoseop Shin on 15/01/2023.
//

#include <cstring>
#include <initializer_list>
#include <ostream>
#include <vector>

class Matrix {
public:
    Matrix(std::initializer_list<int> r1,std::initializer_list<int> r2);
    Matrix(std::initializer_list<int> r1);
    Matrix();
    ~Matrix();
    Matrix(const Matrix& m);
    Matrix& operator=(const Matrix& m);
    Matrix operator+(const Matrix& m);
    friend std::ostream& operator << (std::ostream& os, const Matrix& m);
    Matrix inverse();
private:
    int* data = nullptr;
    size_t row = 0;
    size_t col = 0;
};
