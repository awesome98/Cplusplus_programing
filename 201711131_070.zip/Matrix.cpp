//
// Created by Hoseop Shin on 15/01/2023.
//

#include "Matrix.h"

Matrix::Matrix(std::initializer_list<int> r1, std::initializer_list<int> r2) {
    row = r2.size(); col = r1.size(); data = new int[row*col];
    int cnt=0;
    for(auto& i:r1) {
        data[cnt] = i;
        ++cnt;
    }
    for(auto& j:r2) {
        data[cnt] = j;
        ++cnt;
    }

}

Matrix::~Matrix() {
    delete [] data;
}

Matrix::Matrix(const Matrix& m) {
    if (m.row == 0) {data = m.data; row=m.row; col=m.col;}
    else {
        data=new int[m.row*m.col];
        row=m.row; col=m.col;
        for(int i=0; i<row*col; i++) data[i] = m.data[i];
    }
}

Matrix &Matrix::operator=(const Matrix &m) {
    if(this == &m || m.data == nullptr) return *this;
    row = m.row; col = m.col; data = new int[m.row*m.col];
    for (int i=0; i<row*col; i++) data[i] = m.data[i];
    return *this;
}

Matrix Matrix::operator+(const Matrix &m) {
    Matrix tmp{{0,0},{0,0}};
    for (int i=0; i<row*col; i++)
            tmp.data[i] = data[i] + m.data[i];
    return tmp;
}

Matrix Matrix::inverse() {
    Matrix tmp{{0,0},{0,0}},tmp1;
    if (this->row == 0) return tmp1;
    else {
        double det = 1/(data[0]*data[3]-data[1]*data[2]);
        tmp.data[0] = det * data[3];
        tmp.data[1] = -1 * det * data[1];
        tmp.data[2] = -1 * det * data[2];
        tmp.data[3] = det * data[0];
        tmp.row = row; tmp.col = col;
        return tmp;
    }
}

std::ostream &operator<<(std::ostream &os, const Matrix &m) {
    if (m.row == 0) os << "| |" << std::endl;
    else {
        for (int i = 0; i < m.row * m.col; i += 2) {
            os << "| " << m.data[i] << " " << m.data[i + 1] << " |" << std::endl;
        }
    }
    return os;
}

Matrix::Matrix(std::initializer_list<int> r1) {
}

Matrix::Matrix() {}

