//
// Created by Hoseop Shin on 16/01/2023.
//

#ifndef TEMPLATE_MY_VECTOR_H
#define TEMPLATE_MY_VECTOR_H

#include <algorithm>
#include <initializer_list>
#include <memory>

template<typename T>
class my_vector {
public:
    explicit my_vector(size_t N=0) noexcept{
        _data = new T[N]; _size = N;
        for(int i=0; i<N; i++)
            _data[i] = 0;
    }  // 생성자를 구현하시오

    my_vector(std::initializer_list<int> lst) noexcept : _data(new T[lst.size()]){
        int cnt=0; _size = lst.size();
        for(auto& i:lst){
            _data[cnt] = i;
            ++cnt;
        }
    }  // 생성자를 구현하시오

    my_vector(const my_vector<T>& other) noexcept : _data(new T[other.size()]){
        _size = other.size();
        for(int i=0; i<other.size(); i++)
            _data[i] = other._data[i];
    } // 복사 생성자를 구현하시오 (deep copy)

    T& operator[](int i) {
        return _data[i];
    } // subscript operator, 오퍼레이터 오버로딩 하시오

    size_t size() const {
        return _size;
    } // 멤버 함수를 구현하시오

private:
    size_t _size;
    std::unique_ptr<T[]> _data;
};

#endif //TEMPLATE_MY_VECTOR_H
