//
// Created by Hoseop Shin on 2023-01-10.
//

class Point {
public:
    Point(double x=0, double y=0) : x(x), y(y) {}
    double getX() const {return x;}
    double getY() const {return y;}
private:
    const double x, y;
};
