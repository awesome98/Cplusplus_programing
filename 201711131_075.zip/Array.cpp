#include <iostream>
#include "Array.h"

Array::Array(std::initializer_list<int> args, size_t size):data(new int[size]) {
    _size = size;
    int cnt=0;
    for (auto& i:args){
        data[cnt] = i;
        ++cnt;
    }
}

int &Array::operator[](int index) {
    return data[index];
}

size_t Array::size() const {
    return _size;
}
